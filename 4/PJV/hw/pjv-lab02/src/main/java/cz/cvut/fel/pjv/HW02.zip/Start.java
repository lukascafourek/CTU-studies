/*
 * File name: Start.java
 * Date:      2014/09/04 12:34
 * Author:    Jan Faigl
 */

package cz.cvut.fel.pjv;

// Implementace z ak. roku 2022/2023 (z minuleho letniho semestru) z duvodu opakovani predmetu PJV
public class Start {

   public static void main(String[] args) {
      Lab02 lab = new Lab02();
      lab.homework();
   }
}
