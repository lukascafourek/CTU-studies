#include <stdio.h>

int main() {
    printf("Hello PRP!\n");
    return 0;
}
