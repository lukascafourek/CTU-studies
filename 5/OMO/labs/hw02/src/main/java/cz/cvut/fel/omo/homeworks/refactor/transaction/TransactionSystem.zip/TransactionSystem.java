package cz.cvut.fel.omo.homeworks.refactor.transaction;

public interface TransactionSystem {

    String executeTransaction();
}
