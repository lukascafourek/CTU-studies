/* Testbed, no change expected in this file */

int toplevel_fnc(void);

int main(int argc, char *argv[])
{
  return toplevel_fnc();
}
