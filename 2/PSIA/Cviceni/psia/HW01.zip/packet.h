#ifndef __PACKET_H__

#define __PACKET_H__
#define MAX_PACKET_SIZE 1024
#define MAX_FILE_NAME 64

#include <stdint.h>


typedef struct __attribute__((__packed__)) {
    //uint64_t crc;
    //uint64_t packet_num;
    char payload[MAX_PACKET_SIZE];
} data_packet;

typedef struct __attribute__((__packed__)) {
    char file_name[MAX_FILE_NAME];
    uint64_t num_of_packets;
} entry_packet;

#endif
