function M = quarter2_2009(x)
    t = 2009 + (2 - 1) / 4;
    M = x(1) + x(2) * t;
end
