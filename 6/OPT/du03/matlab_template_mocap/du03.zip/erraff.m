function d = erraff(A)
% function d = erraff(A)
%
% INPUT: 
% A: m-by-n matrix
%    with data
%
% OUTPUT:
% d: m-by-1 matrix
%
b0 = mean(A, 2);
A = A - b0;
[~, S, ~] = svd(A, 'econ');
sigma_squared = diag(S).^2;
total_variance = sum(sigma_squared);
d = total_variance - cumsum(sigma_squared);
% [~, eig_values] = eig(A_centered * A_centered');
% lambda = sort(diag(eig_values), 'descend');
% d = flipud(cumsum(flipud(lambda)));
disp(d)
return
