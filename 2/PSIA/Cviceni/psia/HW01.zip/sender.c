#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "packet.h"
#include <string.h>
#include <unistd.h>

typedef enum {
    OK,
    WRONG_INPUT = 100,
    COMMUNICATION_ERROR,
    FILE_NAME_TOO_LONG,
    FILE_ERROR
} errors;

entry_packet* compute_entry_packet(int argc, char* argv[]);
errors send_content(char* file_name, int socket_desc, struct sockaddr* server_addr);
void error_handler(errors err_num);

int main(int argc, char* argv[]){
    entry_packet* entry = compute_entry_packet(argc, argv);

    struct sockaddr_in server_addr;
    int socket_desc = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(socket_desc < 0){
        printf("Error while creating socket\n");
        return -1;
    }
    printf("Socket created successfully\n");
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(5050);
    server_addr.sin_addr.s_addr = inet_addr("147.32.219.227");

    if(sendto(socket_desc, entry, sizeof(*entry), 0,
         (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0){
        printf("Unable to send message\n");
        return -1;
    }

    int return_value = send_content(argv[1], socket_desc, (struct sockaddr*) &server_addr);
    close(socket_desc);
    return return_value;
}


entry_packet* compute_entry_packet(int argc, char* argv[]){
    if (argc < 2){error_handler(WRONG_INPUT);}

    FILE* file = fopen(argv[1], "rb");
    if (!file){error_handler(FILE_ERROR);}
    fseek(file, 0, SEEK_END);
    uint64_t file_size = ftell(file);
    fclose(file);

    entry_packet* first_packet = (entry_packet*) malloc(sizeof(entry_packet));
    first_packet->num_of_packets = file_size / MAX_PACKET_SIZE + ((file_size % MAX_PACKET_SIZE) && 1);

    char* file_name = strrchr(argv[1], '/');
    //fprintf(stderr, "%p\n", file_name);
    file_name = file_name == NULL ? argv[1] : file_name + 1;
    //fprintf(stderr, "%i", strlen(file_name));
    if(strlen(file_name) > MAX_FILE_NAME){error_handler(FILE_NAME_TOO_LONG);}
    strcpy(first_packet->file_name, file_name);
    //fprintf(stderr, "%s\n", first_packet->file_name);
    return first_packet;
}

errors send_content(char* file_name, int socket_desc, struct sockaddr* server_addr){
    FILE* file = fopen(file_name, "rb");
    data_packet data;
    printf("Sending data packets\n");
    
    size_t data_length = 0;
    while(data_length = fread(data.payload, 1, MAX_PACKET_SIZE, file)){
        if(sendto(socket_desc, &data, sizeof(data) - MAX_PACKET_SIZE + data_length, 0,
              server_addr, sizeof(*server_addr)) < 0){
            printf("Unable to send message\n");
            return COMMUNICATION_ERROR;
        }
        usleep(1000);
    }


    fclose(file);
    shutdown(socket_desc, 2);
    return OK;
}

void error_handler(errors err_num){
    exit(err_num);
}
