#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include "packet.h"

#define LOCAL_PORT 5050

int main (int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "ERROR: need to be run with IP address as argument!\n");
        return EXIT_FAILURE;
    }
    struct sockaddr_in receiver_addr, sender_addr;
    socklen_t sender_struct_length = sizeof(sender_addr);

    memset(&receiver_addr, 0, sizeof(receiver_addr));
    int socket_desc = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (socket_desc < 0) {
        fprintf(stderr, "ERROR creating socket!\n");
        return EXIT_FAILURE;
    }

    receiver_addr.sin_family = AF_INET;
    receiver_addr.sin_port = htons(LOCAL_PORT);
    receiver_addr.sin_addr.s_addr = inet_addr(argv[1]);

    if (bind(socket_desc, (struct sockaddr*)&receiver_addr, sizeof(receiver_addr)) < 0) {
        fprintf(stderr, "Could not bind to the port!\n");
        return EXIT_FAILURE;
    }
    printf("Socket created successfully\n");

    entry_packet entry;
    memset(&sender_addr, 0, sizeof(sender_addr));
    if (recvfrom(socket_desc, &entry, sizeof(entry), 0, (struct sockaddr*)&sender_addr, &sender_struct_length) < 0) {
        fprintf(stderr, "Could not receive entry packet!\n");
        return EXIT_FAILURE;
    }
    printf("Filename: %s\nNumber of packets: %lu\n", entry.file_name, entry.num_of_packets);

    FILE *out = fopen(entry.file_name, "wb");
    if (out == NULL) {
        fprintf(stderr, "ERROR opening file!\n");
        return EXIT_FAILURE;
    }

    int r;
    data_packet data;
    for (uint64_t i = 0; i < entry.num_of_packets; ++i) {
        if ((r = recvfrom(socket_desc, &data, sizeof(data), 0, (struct sockaddr*)&sender_addr, &sender_struct_length)) < 0) {
            fprintf(stderr, "Could not receive data packet!\n");
            return EXIT_FAILURE;
        }
        if (fwrite(data.payload, sizeof(char), r, out) < 0) {
            fprintf(stderr, "ERROR writing into file!\n");
            return EXIT_FAILURE;
        }
    }

    fclose(out);
    shutdown(socket_desc, 2);

    return EXIT_SUCCESS;
}
